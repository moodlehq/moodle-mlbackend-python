Python machine learning backend for Moodle
=======================================================

This package is used by Moodle's mlbackend_python plugin.


