Python machine learning backend for Moodle
=======================================================

This package is used by Moodle's mlbackend_python plugin.

Info about packaging a new version in _readme_moodle.md: https://github.com/moodlehq/moodle-mlbackend-python/blob/master/readme_moodle.md


