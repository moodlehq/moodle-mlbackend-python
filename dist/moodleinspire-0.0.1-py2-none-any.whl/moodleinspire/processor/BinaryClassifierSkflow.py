import tensorflow.contrib.learn as skflow

import BinaryClassifier

class BinaryClassifierSkflow(BinaryClassifier):

    def store_learning_curve(self):
        pass

    def get_classifier(self, X, y):
        return skflow.TensorFlowLinearClassifier(n_classes=2)
