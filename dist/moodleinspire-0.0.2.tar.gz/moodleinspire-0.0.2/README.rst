Python predictions processor backend for Moodle inspire
=======================================================

This package is used by Moodle's predict_python plugin to process predictions.
